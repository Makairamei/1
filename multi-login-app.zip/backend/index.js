import express from "express";
import cors from "cors";
import fs from "fs";
import { v4 as uuidv4 } from "uuid";

const app = express();
const PORT = 3000;
const DB_PATH = "./db.json";

app.use(cors());
app.use(express.json());

// Ensure db.json exists
if (!fs.existsSync(DB_PATH)) fs.writeFileSync(DB_PATH, "{}");

app.post("/token", (req, res) => {
    const token = uuidv4();
    const db = JSON.parse(fs.readFileSync(DB_PATH));
    db[token] = {};
    fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));
    res.json({ token });
});

app.post("/upload", (req, res) => {
    const { token, cookies } = req.body;
    const db = JSON.parse(fs.readFileSync(DB_PATH));
    if (!db[token]) return res.status(400).json({ error: "Token not found" });
    db[token].cookies = cookies;
    fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));
    res.json({ success: true });
});

app.get("/cookies/:token", (req, res) => {
    const db = JSON.parse(fs.readFileSync(DB_PATH));
    const entry = db[req.params.token];
    if (!entry || !entry.cookies) return res.status(404).json({ error: "Cookies not found" });
    res.json({ cookies: entry.cookies });
});

app.listen(PORT, "0.0.0.0", () => console.log(`Backend running on http://0.0.0.0:${PORT}`));
